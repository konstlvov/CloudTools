// Winamp ALT-TAB loader: wa_ldr.cpp
// written by Alexander Avdonin <as12@bk.ru>


#pragma comment(linker, "/subsystem:windows")
#pragma comment(linker, "/entry:_myWinMain")

#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "shell32.lib")

#define _WIN32_WINNT 0x501
#define UNICODE
#define _UNICODE


#include <windows.h>


void _myWinMain() {

	HWND hwndWa = FindWindowEx(NULL, NULL, L"BaseWindow_RootWnd", L"Player Window");
	HWND hwndCl = FindWindowEx(NULL, NULL, L"Winamp PE", L"Winamp Playlist Editor");
	if (!hwndWa && !hwndCl) { // start Winamp

		PWSTR pWinamp = L"winamp.exe";
		
		int nNumArgs;
		PWSTR *ppArgv = CommandLineToArgvW(GetCommandLine(), &nNumArgs);
		if (nNumArgs >= 2)
			pWinamp = ppArgv[1];

		STARTUPINFOW si = { sizeof(si) };
		PROCESS_INFORMATION pi;
		BOOL fOk = CreateProcessW(pWinamp, NULL, NULL, NULL, 
			FALSE, 0, NULL, NULL, &si, &pi);

		if (fOk) {
			CloseHandle(pi.hThread);
			WaitForInputIdle(pi.hProcess, INFINITE);
			CloseHandle(pi.hProcess);
		} else {
			WCHAR szBuff[1024];
			wsprintf(szBuff, L"Could not create process:\r\n%s", pWinamp);
			MessageBox(NULL, szBuff, 
				L"Winamp loader by Alexander Avdonin", MB_OK | MB_ICONERROR);
		}
		HeapFree(GetProcessHeap(), 0, ppArgv);
		if (!fOk) ExitProcess(1);

		hwndWa = FindWindowEx(NULL, NULL, L"BaseWindow_RootWnd", L"Player Window");
		hwndCl = FindWindowEx(NULL, NULL, L"Winamp PE", L"Winamp Playlist Editor");
	}
	if (!hwndWa && !hwndCl) {
		MessageBox(NULL, L"Winamp not found!", 
			L"Winamp loader by Alexander Avdonin", MB_OK | MB_ICONERROR);
		ExitProcess(1);
	}
	if (hwndWa) {
		do {
			SetWindowLongPtr(hwndWa, GWL_EXSTYLE, 
				GetWindowLongPtr(hwndWa, GWL_EXSTYLE) | WS_EX_CONTROLPARENT);
			hwndWa = FindWindowEx(NULL, hwndWa, L"BaseWindow_RootWnd", L"Player Window");
		} while (hwndWa);
	}
	if (hwndCl) {
		SetWindowLongPtr(hwndCl, GWL_EXSTYLE, 
			GetWindowLongPtr(hwndCl, GWL_EXSTYLE) | WS_EX_CONTROLPARENT);
	}
	ExitProcess(0);
}
