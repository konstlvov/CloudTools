Winamp ALT-TAB loader

This tool adds Winamp to the ALT-TAB list when option "Show Winamp in the 
taskbar" is not checked.

Usage:
1) copy wa_ldr.exe to the Winamp directory
2) run wa_ldr.exe to start Winamp

or run from the command line:

    >wa_ldr "C:\Program Files\Winamp\winamp.exe"


You can also run wa_ldr.exe when Winamp is already started.

Copyleft (c) 2005 by Alexander Avdonin
Email: alexander@ntwind.com
